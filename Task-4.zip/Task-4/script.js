document.addEventListener('DOMContentLoaded', () => {
    const apiKey = '5867c7d0f38fd4c645b6c6fa4b477a09';
    const weatherInfo = document.getElementById('weather-info');
    const getWeatherBtn = document.getElementById('get-weather-btn');
    const getCurrentLocationBtn = document.getElementById('get-current-location-btn');
    const locationInput = document.getElementById('location-input');

    getWeatherBtn.addEventListener('click', () => {
        const location = locationInput.value.trim();
        if (location) {
            fetchWeather(location);
        } else {
            alert('Please enter a location');
        }
    });

    getCurrentLocationBtn.addEventListener('click', () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const { latitude, longitude } = position.coords;
                fetchWeatherByCoords(latitude, longitude);
            }, (error) => {
                console.error('Error getting location:', error);
                alert('Unable to retrieve your location');
            });
        } else {
            alert('Geolocation is not supported by this browser');
        }
    });

    const fetchWeather = (location) => {
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}&units=metric`;
        fetchWeatherData(url);
    };

    const fetchWeatherByCoords = (lat, lon) => {
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
        fetchWeatherData(url);
    };

    const fetchWeatherData = (url) => {
        console.log(`Fetching weather data from URL: ${url}`);
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Error: ${response.status} ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Weather data:', data);
                if (data.cod === 200) {
                    displayWeather(data);
                    fetchUVIndex(data.coord.lat, data.coord.lon);
                } else {
                    alert('Location not found');
                }
            })
            .catch(error => {
                console.error('Error fetching weather data:', error);
                alert('Error fetching weather data. Please try again later.');
            });
    };

    const fetchUVIndex = (lat, lon) => {
        const url = `https://api.openweathermap.org/data/2.5/uvi?lat=${lat}&lon=${lon}&appid=${apiKey}`;
        console.log(`Fetching UV Index from URL: ${url}`);
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Error: ${response.status} ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('UV Index data:', data);
                document.getElementById('uv-index').textContent = `UV Index: ${data.value}`;
            })
            .catch(error => {
                console.error('Error fetching UV Index data:', error);
                alert('Error fetching UV Index data. Please try again later.');
            });
    };

    const displayWeather = (data) => {
        const { name, main, weather, wind, sys, visibility, clouds, dt } = data;
        const { temp, feels_like, temp_min, temp_max, humidity, pressure } = main;
        const { description, icon } = weather[0];
        const { speed } = wind;
        const { sunrise, sunset } = sys;

        const sunriseTime = new Date(sunrise * 1000).toLocaleTimeString();
        const sunsetTime = new Date(sunset * 1000).toLocaleTimeString();
        const updateTime = formatDateTime(new Date(dt * 1000));

        document.getElementById('city-name').textContent = name;
        document.getElementById('last-updated').textContent = `Last updated: ${updateTime}`;
        document.getElementById('weather-icon').src = `http://openweathermap.org/img/wn/${icon}@2x.png`;
        document.getElementById('description').textContent = `Weather: ${description}`;
        document.getElementById('temperature').textContent = `Temperature: ${temp}°C`;
        document.getElementById('feels-like').textContent = `Feels Like: ${feels_like}°C`;
        document.getElementById('min-temp').textContent = `Min Temperature: ${temp_min}°C`;
        document.getElementById('max-temp').textContent = `Max Temperature: ${temp_max}°C`;
        document.getElementById('humidity').textContent = `Humidity: ${humidity}%`;
        document.getElementById('pressure').textContent = `Pressure: ${pressure} hPa`;
        document.getElementById('wind-speed').textContent = `Wind Speed: ${speed} m/s`;
        document.getElementById('visibility').textContent = `Visibility: ${visibility / 1000} km`;
        document.getElementById('cloudiness').textContent = `Cloudiness: ${clouds.all}%`;
        document.getElementById('sunrise').textContent = `Sunrise: ${sunriseTime}`;
        document.getElementById('sunset').textContent = `Sunset: ${sunsetTime}`;

        weatherInfo.classList.remove('hidden');

        createWindEffect(speed);
    };

    const formatDateTime = (date) => {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
    };

    const createWindEffect = (speed) => {
        const windEffect = document.createElement('div');
        windEffect.className = 'wind-effect';
        
        const windLineCount = Math.min(10, Math.max(1, Math.floor(speed / 2)));
        for (let i = 0; i < windLineCount; i++) {
            const windLine = document.createElement('div');
            windLine.className = 'wind-line';
            windLine.style.top = `${Math.random() * 100}%`;
            windLine.style.width = `${1 + Math.random() * 3}px`;
            windLine.style.height = `${10 + Math.random() * 30}px`;
            windLine.style.animationDuration = `${2 + Math.random() * 3}s`;
            windLine.style.animationDelay = `${Math.random() * 2}s`;
            windEffect.appendChild(windLine);
        }

        document.querySelector('.container').appendChild(windEffect);

        setTimeout(() => {
            windEffect.remove();
        }, 10000);
    };
});
